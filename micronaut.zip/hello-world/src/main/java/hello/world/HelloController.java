package hello.world;

import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;

/**
 * Created by isuraksha3 on 2/8/2019.
 */
@Controller("/hello")
public class HelloController {
    @Get("/{name}")
    public Greeting hello(String name) {
        Greeting g = new Greeting();
        g.setText("Hello " + name);
        return g;
    }
}

package hello.world;

/**
 * Created by isuraksha3 on 2/11/2019.
 */
public class Greeting {

    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}

package junitTest;

import org.junit.*;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
public class JunitSuite {

    @Before
    public void setUp(){
        System.out.println("Code for before method goes here");
    }
    @BeforeClass
    public static void setUpClass(){
        System.out.println("Code for before class goes here");
    }
    @Test
    public void test(){
        System.out.println("Code for test method goes here");
    }
    @After
    public void tearDown(){
        System.out.println("Code for after method goes here");
    }
    @AfterClass
    public static void tearDownClass(){
        System.out.println("Code for after class goes here");
    }


}

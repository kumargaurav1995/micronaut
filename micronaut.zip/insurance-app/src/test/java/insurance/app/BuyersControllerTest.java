package insurance.app;



import insurance.app.model.Buyers;
import insurance.app.model.BuyersSaveCommand;
import insurance.app.model.BuyersUpdateCommand;
import io.micronaut.context.ApplicationContext;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.client.HttpClient;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.micronaut.runtime.server.EmbeddedServer;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;

/**
 * Created by isuraksha3 on 2/14/2019.
 */
public class BuyersControllerTest {

    private static EmbeddedServer server;
    private static HttpClient client;

    @BeforeClass
    public static void setupServer() {
        server = ApplicationContext
                .build()
                .run(EmbeddedServer.class);
        client = server.getApplicationContext().createBean(HttpClient.class, server.getURL());
    }

    @AfterClass
    public static void stopServer() {
        if (server != null) {
            server.stop();
        }
        if (client != null) {
            client.stop();
        }
    }

    @Rule
    public ExpectedException thrown = ExpectedException.none();


    @Test
    public void testFindNonExistingBuyersReturns404() {
        thrown.expect(HttpClientResponseException.class);
        thrown.expect(hasProperty("response", hasProperty("status", is(HttpStatus.NOT_FOUND))));
        HttpResponse response = client.toBlocking().exchange(HttpRequest.GET("/buyers/99"));
    }


    @Test
    public void testBuyersCrudOperations() {

        List<Long> buyersIds = new ArrayList<>();

        HttpRequest request = HttpRequest.PUT("/buyers", new BuyersUpdateCommand(Long.valueOf(1), "Micro-services", Long.valueOf(1234567890), "male"));
        HttpResponse response = client.toBlocking().exchange(request);
        assertEquals(HttpStatus.NO_CONTENT, response.getStatus());


        request = HttpRequest.POST("/buyers", new BuyersSaveCommand("DevOps", Long.valueOf(1234567890), "male"));
        response = client.toBlocking().exchange(request);
        buyersIds.add(entityId(response));
        assertEquals(HttpStatus.CREATED, response.getStatus());

        Long id = entityId(response);
        buyersIds.add(id);
        request = HttpRequest.GET("/buyers/"+ id);
        Buyers buyers = client.toBlocking().retrieve(request, Buyers.class);
        assertEquals("Micro-services", buyers.getBuyerName());



        // cleanup:
        for (Long buyersId : buyersIds) {
            request = HttpRequest.DELETE("/buyers/"+buyersId);
            response = client.toBlocking().exchange(request);
            assertEquals(HttpStatus.NO_CONTENT, response.getStatus());
        }
    }

    protected Long entityId(HttpResponse response) {
        String path = "/buyers/";
        String value = response.header(HttpHeaders.LOCATION);
        if ( value == null) {
            return null;
        }
        int index = value.indexOf(path);
        if ( index != -1) {
            return Long.valueOf(value.substring(index + path.length()));
        }
        return null;
    }



}

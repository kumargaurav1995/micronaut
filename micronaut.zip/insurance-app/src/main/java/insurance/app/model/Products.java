package insurance.app.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
@Entity
@Table(name = "products")
public class Products {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String productName;

    @NotNull
    @Column(name = "price", nullable = false)
    private String price;

    @NotNull
    @Column(name = "availability", nullable = false)
    private Boolean availability;

    @ManyToOne
    private Offer offer;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Offer getOffer() {
        return offer;
    }

    public void setOffer(Offer offer) {
        this.offer = offer;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Boolean getAvailability() {
        return availability;
    }

    public void setAvailability(Boolean availability) {
        this.availability = availability;
    }



    public Products(@NotNull String productName, @NotNull Boolean availability) {
        this.productName = productName;
        this.availability = availability;

    }

    public Products() {
    }
}

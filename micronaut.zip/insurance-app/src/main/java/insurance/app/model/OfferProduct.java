package insurance.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by isuraksha3 on 2/14/2019.
 */
@Entity
public class OfferProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "ProductSize")
    private Long size;

    @ManyToOne(fetch = FetchType.LAZY)
    BuyerOrder buyerOrder;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("ProductId")
    private Products products;

    @Column(name = "retail_price")
    private Long retailPrice;

    @Column(name = "discounted_price")
    private Long discountedPrice;


    public Products getProducts() {
        return products;
    }

    public void setProducts(Products products) {
        this.products = products;
    }

    public Long getRetailPrice() {
        return retailPrice;
    }

    public void setRetailPrice(Long retailPrice) {
        this.retailPrice = retailPrice;
    }

    public Long getDiscountedPrice() {
        return discountedPrice;
    }

    public void setDiscountedPrice(Long discountedPrice) {
        this.discountedPrice = discountedPrice;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}

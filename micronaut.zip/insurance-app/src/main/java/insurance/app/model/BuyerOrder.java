package insurance.app.model;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

/**
 * Created by isuraksha3 on 2/15/2019.
 */
@Entity
public class BuyerOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "ordered_on")
    private Date orderedOn = new Date();


    @ManyToOne
    private Buyers buyers;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getOrderedOn() {
        return orderedOn;
    }

    public void setOrderedOn(Date orderedOn) {
        this.orderedOn = orderedOn;
    }


    public Buyers getBuyers() {
        return buyers;
    }

    public void setBuyers(Buyers buyers) {
        this.buyers = buyers;
    }
}

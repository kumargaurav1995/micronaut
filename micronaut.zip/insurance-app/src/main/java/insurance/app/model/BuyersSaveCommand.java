package insurance.app.model;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
public class BuyersSaveCommand {

    @NotNull
    private String buyerName;

    @NotNull
    private Long mobile;

    @NotNull
    private String gender;

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public Long getMobile() {
        return mobile;
    }

    public void setMobile(Long mobile) {
        this.mobile = mobile;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public BuyersSaveCommand(@NotNull String buyerName, @NotNull Long mobile, @NotNull String gender) {
        this.buyerName = buyerName;
        this.mobile = mobile;
        this.gender = gender;
    }

    public BuyersSaveCommand() {
    }
}

package insurance.app.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
@Entity
@Table(name = "buyers")
public class Buyers {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "buyer_name", nullable = false)
    private String buyerName;

    @NotNull
    @Column(name = "mobile", nullable = false)
    private Long mobile;

    @NotNull
    @Column(name = "gender", nullable = false)
    private String gender;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public Long getMobile() {
        return mobile;
    }

    public void setMobile(Long mobile) {
        this.mobile = mobile;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }



    public Buyers(@NotNull String buyerName, @NotNull Long mobile, @NotNull String gender, Offer offer, Products products) {
        this.buyerName = buyerName;
        this.mobile = mobile;
        this.gender = gender;
    }

    public Buyers(BuyersSaveCommand bsd) {
        this.buyerName=bsd.getBuyerName();
        this.mobile= bsd.getMobile();
        this.gender=bsd.getGender();
    }

    public Buyers() {
    }
}

package insurance.app.model;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
public class BuyersUpdateCommand {

    @NotNull
    private Long id;

    @NotNull
    private String buyerName;

    @NotNull
    private Long mobile;

    @NotNull
    private String gender;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public Long getMobile() {
        return mobile;
    }

    public void setMobile(Long mobile) {
        this.mobile = mobile;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public BuyersUpdateCommand(@NotNull Long id, @NotNull String buyerName, @NotNull Long mobile, @NotNull String gender) {
        this.id = id;
        this.buyerName = buyerName;
        this.mobile = mobile;
        this.gender = gender;
    }

    public BuyersUpdateCommand() {
    }
}

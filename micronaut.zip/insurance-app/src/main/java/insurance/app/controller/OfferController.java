package insurance.app.controller;

import io.micronaut.http.annotation.Controller;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
@Controller("/offers")
public class OfferController {

}

package insurance.app.controller;

import insurance.app.model.Buyers;
import insurance.app.model.Offer;
import insurance.app.model.Products;
import insurance.app.repository.buyer.BuyerRepository;
import insurance.app.repository.order.OfferRepository;
import insurance.app.repository.product.ProductsRepository;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;

import java.util.List;
import java.util.Optional;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
@Controller("/products")
public class ProductsController {

    protected final ProductsRepository productsRepository;
    protected final OfferRepository offerRepository;
    protected final BuyerRepository buyerRepository;

    public ProductsController(ProductsRepository productsRepository,OfferRepository offerRepository,BuyerRepository buyerRepository) {
        this.productsRepository = productsRepository;
        this.offerRepository = offerRepository;
        this.buyerRepository = buyerRepository;
    }

    @Get("/{id}") // getting number of buyers from product id
    public List<Offer> show(Long id) {

           return offerRepository.getBuyerCount(id);

    }

}

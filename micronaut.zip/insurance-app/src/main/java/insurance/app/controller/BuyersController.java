package insurance.app.controller;

import insurance.app.model.Buyers;
import insurance.app.model.BuyersSaveCommand;
import insurance.app.model.BuyersUpdateCommand;
import insurance.app.repository.buyer.BuyerRepository;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.util.Optional;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
@Controller("/buyers")
public class BuyersController {

    protected final BuyerRepository buyerRepository;

    public BuyersController(BuyerRepository buyerRepository) {
        this.buyerRepository = buyerRepository;
    }

    @Get("/{id}")
    public Buyers show(Long id) {

        Optional<Buyers> buyers = buyerRepository.findById(id);
        if (buyers.isPresent())
            return buyers.get();
        else {
            return null;
        }
    }

    @Put("/")
    public HttpResponse update(@Body @Valid BuyersUpdateCommand command) {
        int numberOfEntitiesUpdated = buyerRepository.update(command.getId(), command.getMobile(),command.getGender(),command.getBuyerName());

        return HttpResponse
                .noContent()
                .header(HttpHeaders.LOCATION, location(command.getId()).getPath());
    }

    @Post("/")
    public HttpResponse<Buyers> save(@Body @Valid BuyersSaveCommand cmd) {
        Buyers buyers = buyerRepository.save(new Buyers(cmd));

        return HttpResponse
                .created(buyers)
                .headers(headers -> headers.location(location(buyers.getId())));
    }

    @Delete("/{id}")
    public HttpResponse delete(Long id) {
        buyerRepository.deleteById(id);
        return HttpResponse.noContent();
    }

    protected URI location(Long id) {
        return URI.create("/buyers/" + id);
    }

    protected URI location(Buyers buyers) {
        return location(buyers.getId());
    }

}

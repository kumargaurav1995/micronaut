package insurance.app.repository.buyer;

import insurance.app.model.Buyers;
import io.micronaut.configuration.hibernate.jpa.scope.CurrentSession;
import io.micronaut.runtime.ApplicationConfiguration;
import io.micronaut.spring.tx.annotation.Transactional;

import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Optional;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
@Singleton
public class BuyerRepositoryImp implements BuyerRepository{

    @PersistenceContext
    private EntityManager entityManager;
    private final ApplicationConfiguration applicationConfiguration;

    public BuyerRepositoryImp(@CurrentSession EntityManager entityManager,
                               ApplicationConfiguration applicationConfiguration) {
        this.entityManager = entityManager;
        this.applicationConfiguration = applicationConfiguration;
    }

    @Override
    @Transactional
    public Buyers save(Buyers buyers) {
        entityManager.persist(buyers);
        return buyers;
    }

    @Override
    @Transactional
    public Optional<Buyers>  findById(Long id) {
        return Optional.ofNullable(entityManager.find(Buyers.class, id));
    }

    @Override
    @Transactional
    public void deleteById(Long id)  {
        findById(id).ifPresent(buyers -> entityManager.remove(buyers));
    }

    @Override
    @Transactional
    public int update(Long id, Long mobile, String gender, String buyerName) {
        return entityManager.createQuery("UPDATE Buyers b SET buyer_name = :name, gender = :gender, mobile = :mobile where id = :id")
                .setParameter("name", buyerName)
                .setParameter("id", id)
                .setParameter("gender", gender)
                .setParameter("mobile", mobile)
                .executeUpdate();

    }
}



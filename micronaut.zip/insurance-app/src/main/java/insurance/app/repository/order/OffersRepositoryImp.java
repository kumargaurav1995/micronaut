package insurance.app.repository.order;

import insurance.app.model.Offer;
import insurance.app.model.OfferProduct;
import io.micronaut.configuration.hibernate.jpa.scope.CurrentSession;
import io.micronaut.runtime.ApplicationConfiguration;
import io.micronaut.spring.tx.annotation.Transactional;

import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;
import java.util.Optional;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
@Singleton
public class OffersRepositoryImp implements OfferRepository {

    @PersistenceContext
    private EntityManager entityManager;
    private final ApplicationConfiguration applicationConfiguration;

    public OffersRepositoryImp(@CurrentSession EntityManager entityManager,
                               ApplicationConfiguration applicationConfiguration) {
        this.entityManager = entityManager;
        this.applicationConfiguration = applicationConfiguration;
    }

    @Transactional
    @Override
    public void add(Offer offer) {
        entityManager.persist(offer);
    }

    @Override
    @Transactional
    public Optional<Offer> findById(Long id) {
        return Optional.ofNullable(entityManager.find(Offer.class, id));
    }

    @Override
    @Transactional
    public List<OfferProduct> getBuyerCount(Long id) {

        TypedQuery<OfferProduct> query = entityManager.createQuery("select o from OfferProduct o where o.buyerOrder.buyers.id=:id ", OfferProduct.class);
        query.setParameter("id", id);
        return query.getResultList();

    }


//    @Override
//    @Transactional
//    public int getBuyerCount(Long id, Long mobile, String gender, String buyerName) {
//        return entityManager.createQuery("UPDATE Buyers b SET buyer_name = :name, gender = :gender, mobile = :mobile where id = :id"
//        "select COUNT(DISTINCT buyer_id) from offer o where o."
//        )
//                .setParameter("name", buyerName)
//                .setParameter("id", id)
//                .setParameter("gender", gender)
//                .setParameter("mobile", mobile)
//                .executeUpdate();


}

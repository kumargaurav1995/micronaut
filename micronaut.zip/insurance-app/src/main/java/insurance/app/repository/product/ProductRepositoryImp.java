package insurance.app.repository.product;

import insurance.app.model.Buyers;
import insurance.app.model.Products;
import io.micronaut.configuration.hibernate.jpa.scope.CurrentSession;
import io.micronaut.runtime.ApplicationConfiguration;
import io.micronaut.spring.tx.annotation.Transactional;
import io.reactivex.Maybe;
import io.reactivex.Single;

import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import java.util.Optional;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
@Singleton
public class ProductRepositoryImp implements ProductsRepository {

    @PersistenceContext
    private EntityManager entityManager;
    private final ApplicationConfiguration applicationConfiguration;

    public ProductRepositoryImp(@CurrentSession EntityManager entityManager,
                              ApplicationConfiguration applicationConfiguration) {
        this.entityManager = entityManager;
        this.applicationConfiguration = applicationConfiguration;
    }

    @Override
    @Transactional
    public Optional<Products> findById(Long id) {

            return Optional.ofNullable(entityManager.find(Products.class, id));
    }

    @Override
    public Single add(Products products) {
        return null;
    }

    @Override
    public Single<List> findAll() {
        return null;
    }




    /*@Override
    public Single add(Products product) {
        return Single.fromPublisher(
                getCollection().insertOne(product)
        ).map(success -> product);
    }
    @Override
    public Single<List> findAll() {
        return Flowable.fromPublisher(
                getCollection().find()
        ).toList();
    }
    @Override
    public Maybe findOne(String productCode) {
        return Flowable.fromPublisher(
                getCollection()
                        .find(Filters.eq("code", productCode))
                        .limit(1)
        ).firstElement();
    }*/
}

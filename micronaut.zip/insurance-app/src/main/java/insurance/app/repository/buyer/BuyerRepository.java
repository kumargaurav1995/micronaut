package insurance.app.repository.buyer;

import insurance.app.model.Buyers;

import java.util.Optional;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
public interface BuyerRepository {

    Buyers save(Buyers buyers);

    Optional<Buyers> findById(Long id);

    void deleteById(Long id);

    int update(Long id,Long mobile, String gender, String buyerName);

}

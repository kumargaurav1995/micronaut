package insurance.app.repository.order;

import insurance.app.model.Offer;

import java.util.List;
import java.util.Optional;


/**
 * Created by isuraksha3 on 2/13/2019.
 */

public interface OfferRepository {

    void add(Offer offer);

    Optional<Offer> findById(Long id);

    List<Offer> getBuyerCount(Long id);

}

package insurance.app.repository.product;


import insurance.app.model.Products;
import io.reactivex.Single;

import java.util.List;
import java.util.Optional;

/**
 * Created by isuraksha3 on 2/13/2019.
 */
public interface ProductsRepository {

    Single add(Products products);

    Single<List> findAll();

    Optional<Products> findById(Long id);
}

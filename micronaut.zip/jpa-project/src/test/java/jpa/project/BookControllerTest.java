package jpa.project;

import io.micronaut.context.ApplicationContext;
import io.micronaut.core.type.Argument;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.client.HttpClient;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.micronaut.runtime.server.EmbeddedServer;
import jpa.project.model.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;

/**
 * Created by isuraksha3 on 2/14/2019.
 */
public class BookControllerTest {
    private static EmbeddedServer server;
    private static HttpClient client;

    @BeforeClass
    public static void setupServer() {
        server = ApplicationContext
                .build()
                .run(EmbeddedServer.class);
        client = server.getApplicationContext().createBean(HttpClient.class, server.getURL());
    }

    @AfterClass
    public static void stopServer() {
        if (server != null) {
            server.stop();
        }
        if (client != null) {
            client.stop();
        }
    }

    @Rule
    public ExpectedException thrown = ExpectedException.none();


    @Test
    public void testFindNonExistingBookReturns404() {
        thrown.expect(HttpClientResponseException.class);
        thrown.expect(hasProperty("response", hasProperty("status", is(HttpStatus.NOT_FOUND))));
        HttpResponse response = client.toBlocking().exchange(HttpRequest.GET("/books/99"));
    }


    @Test
    public void testBookCrudOperations() {

        List<Long> bookIds = new ArrayList<>();

        HttpRequest request = HttpRequest.PUT("/books", new BookUpdateCommand(Long.valueOf(1), "Micro-services", "978-3-16-148410-1", Long.valueOf(1)));
        HttpResponse response = client.toBlocking().exchange(request);
        assertEquals(HttpStatus.NO_CONTENT, response.getStatus());


        request = HttpRequest.POST("/books", new BookSaveCommand("DevOps","978-3-16-148410-7"));
        response = client.toBlocking().exchange(request);
        bookIds.add(entityId(response));
        assertEquals(HttpStatus.CREATED, response.getStatus());



         request = HttpRequest.POST("/books", new BookSaveCommand("Micro-services","978-3-16-148410-1"));
         response = client.toBlocking().exchange(request);
        assertEquals(HttpStatus.CREATED, response.getStatus());

        Long id = entityId(response);
        bookIds.add(id);
        request = HttpRequest.GET("/books/"+ id);
        Book book = client.toBlocking().retrieve(request, Book.class);
        assertEquals("Micro-services", book.getName());

        request = HttpRequest.GET("/books/" + id);
        book = client.toBlocking().retrieve(request, Book.class);
        assertEquals("Micro-services", book.getName());


        // cleanup:
        for (Long bookId : bookIds) {
            request = HttpRequest.DELETE("/books/"+bookId);
            response = client.toBlocking().exchange(request);
            assertEquals(HttpStatus.NO_CONTENT, response.getStatus());
        }
    }

    protected Long entityId(HttpResponse response) {
        String path = "/books/";
        String value = response.header(HttpHeaders.LOCATION);
        if ( value == null) {
            return null;
        }
        int index = value.indexOf(path);
        if ( index != -1) {
            return Long.valueOf(value.substring(index + path.length()));
        }
        return null;
    }



}

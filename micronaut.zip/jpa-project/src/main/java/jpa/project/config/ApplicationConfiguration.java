package jpa.project.config;

import javax.validation.constraints.NotNull;

/**
 * Created by isuraksha3 on 2/11/2019.
 */
public interface ApplicationConfiguration {
    @NotNull Integer getMax();
}

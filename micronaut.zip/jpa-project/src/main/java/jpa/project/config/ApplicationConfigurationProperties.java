package jpa.project.config;

import io.micronaut.context.annotation.ConfigurationProperties;

import javax.validation.constraints.NotNull;

/**
 * Created by isuraksha3 on 2/11/2019.
 */
@ConfigurationProperties("application")
public class ApplicationConfigurationProperties implements ApplicationConfiguration {


    protected final Integer DEFAULT_MAX = 10;

    private Integer max = DEFAULT_MAX;

    @Override
    public Integer getMax() {
        return max;
    }

    public void setMax(Integer max) {
        if(max != null) {
            this.max = max;
        }
    }
}

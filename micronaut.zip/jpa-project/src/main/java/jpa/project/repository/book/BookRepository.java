package jpa.project.repository.book;

import jpa.project.model.Book;
import jpa.project.model.Genre;
import jpa.project.model.SortingAndOrderArguments;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Optional;

/**
 * Created by isuraksha3 on 2/12/2019.
 */
public interface BookRepository {
    Optional<Book> findById(@NotNull Long id);

    Book save(@NotBlank String isbn, @NotBlank String bookName,  Long genreId);

    void deleteById(@NotNull Long id);

   // List<Book> findAll(@NotNull SortingAndOrderArguments args);

    int update( @NotNull Long id,@NotBlank String isbn, @NotBlank String bookName);

    Book save(Book book);
}

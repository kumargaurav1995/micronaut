package jpa.project.repository.book;

import io.micronaut.configuration.hibernate.jpa.scope.CurrentSession;
import io.micronaut.spring.tx.annotation.Transactional;
import jpa.project.config.ApplicationConfiguration;
import jpa.project.model.Book;
import jpa.project.repository.book.BookRepository;

import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Created by isuraksha3 on 2/12/2019.
 */
@Singleton
public class BookRepositoryImpl implements BookRepository {
    @PersistenceContext
    private EntityManager entityManager;
    private final ApplicationConfiguration applicationConfiguration;

    public BookRepositoryImpl(@CurrentSession EntityManager entityManager,
                               ApplicationConfiguration applicationConfiguration) {
        this.entityManager = entityManager;
        this.applicationConfiguration = applicationConfiguration;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Book> findById( Long id) {
        return Optional.ofNullable(entityManager.find(Book.class, id));
    }

    @Override
    @Transactional
    public Book save(String name, String isbn, Long genreId) {
        Book book = new Book(name,isbn,genreId);
        entityManager.persist(book);
        return book;
    }

    @Override
    @Transactional
    public void deleteById( Long id) {
        findById(id).ifPresent(book -> entityManager.remove(book));
    }

    private final static List<String> VALID_PROPERTY_NAMES = Arrays.asList("id", "name");

//    @Transactional
//    public List<Book> findAll(@NotNull SortingAndOrderArguments args) {
//        String qlString = "SELECT g FROM Book as g";
//        if (args.getOrder().isPresent() && args.getSort().isPresent() && VALID_PROPERTY_NAMES.contains(args.getSort().get())) {
//            qlString += " ORDER BY g." + args.getSort().get() + " " + args.getOrder().get().toLowerCase();
//        }
//        TypedQuery<Genre> query = entityManager.createQuery(qlString, Book.class);
//        query.setMaxResults(args.getMax().orElseGet(applicationConfiguration::getMax));
//        args.getOffset().ifPresent(query::setFirstResult);
//
//        return query.getResultList();
//
//    }

    @Override
    @Transactional
    public int update(@NotNull Long id, @NotBlank String isbn, @NotBlank String bookName) {
        return entityManager.createQuery("UPDATE Book b SET name = :name, isbn = :isbn where id = :id")
                .setParameter("name", bookName)
                .setParameter("id", id)
                .setParameter("isbn", isbn)
                .executeUpdate();
    }

    @Override
    @Transactional
    public Book save(Book book) {
      entityManager.persist(book);
        return  book;
    }
}

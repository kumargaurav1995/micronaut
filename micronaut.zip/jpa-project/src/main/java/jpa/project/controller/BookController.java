package jpa.project.controller;

import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.*;
import io.micronaut.validation.Validated;
import jpa.project.model.*;
import jpa.project.repository.book.BookRepository;
import jpa.project.repository.genre.GenreRepository;

import javax.validation.Valid;
import java.net.URI;
import java.util.Optional;

/**
 * Created by isuraksha3 on 2/11/2019.
 */
@Validated
@Controller("/books")
public class BookController {
    protected final BookRepository bookRepository;
    protected final GenreRepository genreRepository;

    public BookController(GenreRepository genreRepository, BookRepository bookRepository) {
        this.bookRepository = bookRepository;
        this.genreRepository = genreRepository;
    }

    @Get("/{bookid}")
    public Book show(Long bookid) {
        Optional<Book> book = bookRepository.findById(bookid);
        if (book.isPresent())
        return book.get();
        else{
            return  null;
        }

    }

    @Put("/")
    public HttpResponse update(@Body @Valid BookUpdateCommand command) {
        Optional<Genre> genre = genreRepository.findById(command.getGenreId());
        if (genre.isPresent()) {
           bookRepository.update(command.getId(), command.getIsbn(), command.getName());
        }

        return HttpResponse
                .noContent()
                .header(HttpHeaders.LOCATION, location(command.getId()).getPath());
    }

    @Delete("/{bookid}")
    public HttpResponse delete( Long bookid) {

        Optional<Book> book = bookRepository.findById(bookid);
        if (book.isPresent())
            bookRepository.deleteById(bookid);

            return HttpResponse.noContent();

    }

    protected URI location(Long bookid) {
        return URI.create("/books/" + bookid);
    }

    protected URI location(Book book) {
        return location(book.getId());
    }


    @Post("/")
    public HttpResponse save(@Body @Valid BookSaveCommand bsd) {
        Book book = bookRepository.save(new Book(bsd));
        return HttpResponse.created(book).headers(headers -> headers.location(location(book.getId())));

    }
}

package jpa.project.model;

/**
 * Created by isuraksha3 on 2/12/2019.
 */
public class BookUpdateCommand {

    private Long id;

    private String name;

    private String isbn;

    private Long genreId;

    public Long getGenreId() {
        return genreId;
    }

    public void setGenreId(Long genreId) {
        this.genreId = genreId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public BookUpdateCommand(Long id, String name, String isbn, Long genreId) {
        this.id = id;
        this.name = name;
        this.isbn = isbn;
        this.genreId = genreId;
    }

    public BookUpdateCommand() {
    }
}

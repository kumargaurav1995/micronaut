package jpa.project.model;

import javax.validation.constraints.NotBlank;

/**
 * Created by isuraksha3 on 2/11/2019.
 */
public class BookSaveCommand {

    private Genre genre;

    private String name;

    private String isbn;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public BookSaveCommand(String name, String isbn) {
        this.name = name;
        this.isbn = isbn;
    }

    public BookSaveCommand() {
    }

    public Genre getGenre() {
        return genre;
    }

    public void setGenre(Genre genre) {
        this.genre = genre;
    }
}

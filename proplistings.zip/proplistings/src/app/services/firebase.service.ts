import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireDatabase} from 'angularfire2/database';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  listings: Observable<Listing[]>;



  constructor(private af: AngularFireDatabase) { }

  getListing(): Observable<any> {
    console.log('hello');
      this.af.list('/listings');
return this.listings;
    }
}
interface Listing {
  s: string;
}

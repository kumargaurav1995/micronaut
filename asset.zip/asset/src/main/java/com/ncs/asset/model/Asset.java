package com.ncs.asset.model;

import lombok.*;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
@Data
@NoArgsConstructor
public class Asset {

    @Id
    @GeneratedValue
    private int assetId;

    @Column
    private String typeName;

    @Column
    private String groupName;

    @Column
    private String assetName;

    @Column
    private String vendorName;

    @Column
    private Long cost;

    @Column
    private String description;

    @Column
    private Date purchaseDate;

    @Column
    private boolean isDiscarded;

    @Column
    private Date discardDate;

    @Column
    private String reasonForDiscard;

    @ManyToOne
    private Employee employee;

    @ManyToOne
    private Location location;

}

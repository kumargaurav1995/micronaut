package com.glabbr.chat;

import com.glabbr.chat.model.Users;
import com.glabbr.chat.repository.UsersRepository;
import com.glabbr.chat.service.UsersService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.util.AssertionErrors.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ChatApplicationTests {

	@Mock
	UsersRepository usersRepository;

	@InjectMocks
	UsersService usersService;


	@Test
	public void contextLoads() {
	}

	@Test
	public void findMessages(){

        Users users = new Users();
        users.setName("user1");
        users.setTimeStamp(new Date());
        users.setMessages("hello");
        users.setId(1);
		List<Users> usersList = new ArrayList<>();
		usersList.add(users);
		//verify(usersRepository, times(1)).save(users);
		when(usersRepository.findAll()).thenReturn(usersList);
		List<Users> usersList1 = new ArrayList<>();
		usersList1 = usersRepository.findAll();
		assertTrue("success",usersList1.size()>0);

	}

}

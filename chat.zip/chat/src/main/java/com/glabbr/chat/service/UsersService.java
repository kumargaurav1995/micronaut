package com.glabbr.chat.service;

import com.glabbr.chat.dto.UsersDto;
import com.glabbr.chat.model.Users;
import com.glabbr.chat.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class UsersService {

    @Autowired
    UsersRepository usersRepository;

    public List<Users> findUser1Messages() {

        List<Users> user1 = new ArrayList<>();
        if(user1.equals(null)){

            user1 = usersRepository.findAll();
        }
        usersRepository.findAll();
       return user1.stream().filter(users -> users.getName().equals("user1")).collect(Collectors.toList());

   }


    public List<Users> findUser2Messages() {
        List<Users> user1= usersRepository.findAll();

        return user1.stream().filter(users -> users.getName().equals("user2")).collect(Collectors.toList());

    }
    public List<Users> saveUser1(UsersDto usersDto) {
        Users users = new Users(usersDto.getMessages());
        users.setTimeStamp(new Date());
        users.setName("user1");
        usersRepository.save(users);
        return usersRepository.findAll();
    }

    public List<Users> saveUser2(UsersDto usersDto) {
        Users users = new Users(usersDto.getMessages());
        users.setTimeStamp(new Date());
        users.setName("user2");
        usersRepository.save(users);
        return usersRepository.findAll();
    }

}

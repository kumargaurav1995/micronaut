package com.glabbr.chat.controller;

import com.glabbr.chat.dto.UsersDto;
import com.glabbr.chat.model.Users;
import com.glabbr.chat.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value = "/users")
public class UsersController {


    @Autowired
    UsersService usersService;

    @GetMapping(value = "/all/user1")
    public List<Users> getAlluser1()
    {
      return usersService.findUser1Messages();
    }
    @GetMapping(value = "/all/user2")
    public List<Users> getAll()
    {
        return usersService.findUser2Messages();
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping(value = "/save/user1")
    public List<Users> persistuser1(@RequestBody final UsersDto usersDto) {

        return usersService.saveUser1(usersDto);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping(value = "/save/user2")
    public List<Users> persistUser2(@RequestBody final UsersDto usersDto) {

        return usersService.saveUser2(usersDto);
    }
}

package com.glabbr.chat.dto;

import java.util.Date;

public class UsersDto {

    private String messages;

    public String getMessages() {
        return messages;
    }

    public void setMessages(String messages) {
        this.messages = messages;
    }
}

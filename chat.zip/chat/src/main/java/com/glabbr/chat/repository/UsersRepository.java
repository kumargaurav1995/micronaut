package com.glabbr.chat.repository;

import com.glabbr.chat.model.Users;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsersRepository extends JpaRepository<Users, Integer> {
}

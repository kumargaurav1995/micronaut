export interface IUserChat{
    id: number,
    name: string,
    messages: string,
    timpeStamp: string
}
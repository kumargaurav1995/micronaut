export class Courses {
    constructor(
        public name: string,
        public course: string,
    ) {
    }
}
